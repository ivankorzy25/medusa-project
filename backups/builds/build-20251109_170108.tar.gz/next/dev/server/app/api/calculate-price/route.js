var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/calculate-price/route.js")
R.c("server/chunks/node_modules_next_b8c12593._.js")
R.c("server/chunks/[root-of-the-server]__ef96dd56._.js")
R.c("server/chunks/_next-internal_server_app_api_calculate-price_route_actions_49bb39b6.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/calculate-price/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/calculate-price/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
