var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/product-metadata/[id]/route.js")
R.c("server/chunks/node_modules_next_97ef8137._.js")
R.c("server/chunks/[root-of-the-server]__71ca86c5._.js")
R.c("server/chunks/_next-internal_server_app_api_product-metadata_[id]_route_actions_0e6f0a2e.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/product-metadata/[id]/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/product-metadata/[id]/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
