var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/exchange-rates/route.js")
R.c("server/chunks/node_modules_next_3f9f12be._.js")
R.c("server/chunks/[root-of-the-server]__970845e0._.js")
R.c("server/chunks/_next-internal_server_app_api_exchange-rates_route_actions_16936656.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/exchange-rates/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/exchange-rates/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
