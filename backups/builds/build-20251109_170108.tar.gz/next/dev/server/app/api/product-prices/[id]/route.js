var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/product-prices/[id]/route.js")
R.c("server/chunks/node_modules_next_729cbe15._.js")
R.c("server/chunks/[root-of-the-server]__ae833362._.js")
R.c("server/chunks/_next-internal_server_app_api_product-prices_[id]_route_actions_84127387.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/product-prices/[id]/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/product-prices/[id]/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
