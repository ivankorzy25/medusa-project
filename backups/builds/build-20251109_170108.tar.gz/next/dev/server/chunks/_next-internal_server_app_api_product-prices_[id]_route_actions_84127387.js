module.exports = [
"[project]/.next-internal/server/app/api/product-prices/[id]/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_api_product-prices_%5Bid%5D_route_actions_84127387.js.map