module.exports = [
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[project]/src/app/api/exchange-rates/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GET",
    ()=>GET
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
;
async function GET() {
    try {
        console.log('[API Route] Fetching exchange rates from DolarAPI.com');
        // Obtener cotizaciones de DolarAPI.com
        const response = await fetch('https://dolarapi.com/v1/dolares', {
            cache: 'no-store',
            next: {
                revalidate: 300
            }
        });
        if (!response.ok) {
            throw new Error(`DolarAPI error: ${response.status}`);
        }
        const data = await response.json();
        console.log('[API Route] Exchange rates fetched successfully from DolarAPI');
        // Mapear a nuestro formato
        const exchangeRates = data.map((item)=>({
                tipo: mapDolarApiToType(item.casa),
                compra: item.compra,
                venta: item.venta,
                fuente: item.nombre,
                ultima_actualizacion: item.fechaActualizacion
            }));
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: true,
            data: exchangeRates
        });
    } catch (error) {
        console.error('[API Route] Error fetching exchange rates:', error);
        // Fallback con valores por defecto
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: false,
            error: error.message || 'No se pudieron obtener las cotizaciones',
            data: [
                {
                    tipo: 'oficial',
                    compra: 1015.50,
                    venta: 1055.50,
                    fuente: 'Fallback',
                    ultima_actualizacion: new Date().toISOString()
                }
            ]
        });
    }
}
/**
 * Mapea los nombres de DolarAPI a nuestros tipos
 */ function mapDolarApiToType(casa) {
    const mapping = {
        oficial: 'oficial',
        blue: 'blue',
        bolsa: 'mep',
        contadoconliqui: 'ccl',
        mayorista: 'mayorista',
        cripto: 'cripto',
        tarjeta: 'tarjeta'
    };
    return mapping[casa.toLowerCase()] || casa.toLowerCase();
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__970845e0._.js.map