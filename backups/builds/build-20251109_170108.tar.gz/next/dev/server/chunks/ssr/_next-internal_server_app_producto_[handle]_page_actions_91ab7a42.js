module.exports = [
"[project]/.next-internal/server/app/producto/[handle]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_producto_%5Bhandle%5D_page_actions_91ab7a42.js.map