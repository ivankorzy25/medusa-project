module.exports = [
"[project]/.next-internal/server/app/api/calculate-price/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_api_calculate-price_route_actions_49bb39b6.js.map