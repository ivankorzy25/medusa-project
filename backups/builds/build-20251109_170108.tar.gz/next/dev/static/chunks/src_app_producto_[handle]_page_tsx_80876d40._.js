(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_ec16b62e._.js",
  "static/chunks/node_modules_37e0f17b._.js",
  "static/chunks/node_modules_yet-another-react-lightbox_dist_75f8b17d._.css"
],
    source: "dynamic"
});
