(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_globals_91e4631d.css",
  "static/chunks/node_modules_757b770b._.js",
  "static/chunks/src_f2ec321d._.js"
],
    source: "dynamic"
});
